## Testing Effect programs
